import sqlite3
import logging
from datetime import datetime, timedelta

class Database:
    def __init__(self, db_file):
        self.db_file = db_file
        self.init_db()

    def _execute(self, query, params=(), fetchone=False, fetchall=False, commit=False):
        with sqlite3.connect(self.db_file) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(query, params)
            if commit:
                conn.commit()
            if fetchone:
                return cursor.fetchone()
            if fetchall:
                return cursor.fetchall()
            return None

    def get_db_connection(self):
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        self._execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER NOT NULL DEFAULT 0
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS vps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                container_name TEXT NOT NULL UNIQUE,
                cpu INTEGER NOT NULL,
                ram INTEGER NOT NULL,
                disk INTEGER NOT NULL,
                cost_credits INTEGER NOT NULL,
                due_date DATETIME NOT NULL,
                status TEXT NOT NULL DEFAULT 'active',
                ssh_link TEXT,
                ssh_port INTEGER,
                ssh_password TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                track_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                credits INTEGER NOT NULL,
                expiration_time TIMESTAMP NOT NULL,
                attributed BOOLEAN NOT NULL DEFAULT 0
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS port_forwards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                container_name TEXT NOT NULL,
                external_port INTEGER NOT NULL,
                internal_port INTEGER NOT NULL,
                protocol TEXT NOT NULL,
                device_name TEXT NOT NULL UNIQUE,
                FOREIGN KEY (container_name) REFERENCES vps(container_name) ON DELETE CASCADE,
                UNIQUE(external_port, protocol)
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS channel_stats (
                channel_key TEXT PRIMARY KEY,
                channel_id INTEGER
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS giveaway_stats (
                id INTEGER PRIMARY KEY,
                last_transaction_count INTEGER NOT NULL DEFAULT 0
            )
        ''')

        self._execute('''
            CREATE TABLE IF NOT EXISTS monthly_trial_users (
                user_id INTEGER PRIMARY KEY
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS monthly_trial_message (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS invited_members (
                member_id INTEGER PRIMARY KEY,
                inviter_id INTEGER NOT NULL,
                joined_at DATETIME NOT NULL,
                left_at DATETIME,
                reward_given BOOLEAN NOT NULL DEFAULT 0
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS tos_message (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS suspicion_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                container_name TEXT NOT NULL,
                process_list TEXT NOT NULL,
                detected_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Migrations
        with sqlite3.connect(self.db_file) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Check and add columns to transactions table
            cursor.execute("PRAGMA table_info(transactions)")
            columns = [column['name'] for column in cursor.fetchall()]
            if 'attributed' not in columns:
                self._execute("ALTER TABLE transactions ADD COLUMN attributed BOOLEAN NOT NULL DEFAULT 0", commit=True)
                logging.info("Database migration: Added 'attributed' column to 'transactions' table.")

            # Check and add columns to vps table
            cursor.execute("PRAGMA table_info(vps)")
            columns = [column['name'] for column in cursor.fetchall()]
            
            if 'ssh_link' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN ssh_link TEXT", commit=True)
                logging.info("Database migration: Added 'ssh_link' column to 'vps' table.")
            
            if 'username' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN username TEXT", commit=True)
                logging.info("Database migration: Added 'username' column to 'vps' table.")
            
            if 'ssh_port' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN ssh_port INTEGER", commit=True)
                logging.info("Database migration: Added 'ssh_port' column to 'vps' table.")
            
            if 'ssh_password' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN ssh_password TEXT", commit=True)
                logging.info("Database migration: Added 'ssh_password' column to 'vps' table.")

            if 'is_suspended' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN is_suspended BOOLEAN NOT NULL DEFAULT 0", commit=True)
                logging.info("Database migration: Added 'is_suspended' column to 'vps' table.")

            if 'suspicion_count' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN suspicion_count INTEGER NOT NULL DEFAULT 0", commit=True)
                logging.info("Database migration: Added 'suspicion_count' column to 'vps' table.")

            # Check and add columns to users table
            cursor.execute("PRAGMA table_info(users)")
            columns = [column['name'] for column in cursor.fetchall()]
            if 'pending_balance' not in columns:
                self._execute("ALTER TABLE users ADD COLUMN pending_balance INTEGER NOT NULL DEFAULT 0", commit=True)
                logging.info("Database migration: Added 'pending_balance' column to 'users' table.")

        logging.info("Database initialized.")

    def suspend_vps(self, container_name):
        self._execute("UPDATE vps SET is_suspended = 1 WHERE container_name = ?", (container_name,), commit=True)
        logging.info(f"VPS {container_name} has been suspended.")

    def is_vps_suspended(self, container_name):
        result = self._execute("SELECT is_suspended FROM vps WHERE container_name = ?", (container_name,), fetchone=True)
        return result['is_suspended'] == 1 if result else False

    def increment_suspicion_count(self, container_name):
        self._execute("UPDATE vps SET suspicion_count = suspicion_count + 1 WHERE container_name = ?", (container_name,), commit=True)
        result = self._execute("SELECT suspicion_count FROM vps WHERE container_name = ?", (container_name,), fetchone=True)
        return result['suspicion_count'] if result else 0

    def reset_suspicion_count(self, container_name):
        self._execute("UPDATE vps SET suspicion_count = 0 WHERE container_name = ?", (container_name,), commit=True)


    def get_balance(self, user_id):
        result = self._execute("SELECT balance FROM users WHERE user_id = ?", (user_id,), fetchone=True)
        return result['balance'] if result else 0

    def get_pending_balance(self, user_id):
        result = self._execute("SELECT pending_balance FROM users WHERE user_id = ?", (user_id,), fetchone=True)
        return result['pending_balance'] if result else 0

    def add_credits(self, user_id, amount):
        self._execute("INSERT OR IGNORE INTO users (user_id, balance, pending_balance) VALUES (?, 0, 0)", (user_id,), commit=True)
        self._execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id), commit=True)

    def add_pending_credits(self, user_id, amount):
        self._execute("INSERT OR IGNORE INTO users (user_id, balance, pending_balance) VALUES (?, 0, 0)", (user_id,), commit=True)
        self._execute("UPDATE users SET pending_balance = pending_balance + ? WHERE user_id = ?", (amount, user_id), commit=True)
        logging.info(f"User {user_id} received {amount} pending credits.")

    def remove_pending_credits(self, user_id, amount):
        self._execute("UPDATE users SET pending_balance = pending_balance - ? WHERE user_id = ?", (amount, user_id), commit=True)
        logging.info(f"User {user_id} lost {amount} pending credits.")

    def move_pending_to_balance(self, user_id, amount):
        self._execute("UPDATE users SET balance = balance + ?, pending_balance = pending_balance - ? WHERE user_id = ?", (amount, amount, user_id), commit=True)
        logging.info(f"User {user_id} moved {amount} pending credits to balance.")
    
    def set_balance(self, user_id, amount):
        self._execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,), commit=True)
        self._execute("UPDATE users SET balance = ? WHERE user_id = ?", (amount, user_id), commit=True)
        logging.info(f"User {user_id}'s balance set to {amount}.")

    def add_vps(self, user_id, username, container_name, cpu, ram, disk, cost_credits, ssh_link=None, ssh_port=None, ssh_password=None):
        due_date = datetime.now() + timedelta(days=30)
        self._execute(
            "INSERT INTO vps (user_id, username, container_name, cpu, ram, disk, cost_credits, due_date, ssh_link, ssh_port, ssh_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, username, container_name, cpu, ram, disk, cost_credits, due_date, ssh_link, ssh_port, ssh_password),
            commit=True
        )
        logging.info(f"VPS added for user {user_id} with container {container_name}, SSH port {ssh_port}")

    def get_user_vps(self, user_id):
        return self._execute("SELECT * FROM vps WHERE user_id = ?", (user_id,), fetchall=True)

    def get_all_vps(self):
        return self._execute("SELECT * FROM vps", fetchall=True)

    def get_vps_by_id(self, vps_id):
        return self._execute("SELECT * FROM vps WHERE id = ?", (vps_id,), fetchone=True)

    def get_vps_by_container_name(self, container_name):
        return self._execute("SELECT * FROM vps WHERE container_name = ?", (container_name,), fetchone=True)

    def update_vps_due_date(self, vps_id):
        new_due_date = datetime.now() + timedelta(days=30)
        self._execute("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id), commit=True)
        logging.info(f"VPS {vps_id} renewed. New due date: {new_due_date}")

    def extend_vps_due_date(self, vps_id, months):
        vps = self.get_vps_by_id(vps_id)
        if vps:
            current_due_date = datetime.strptime(vps['due_date'], '%Y-%m-%d %H:%M:%S.%f')
            new_due_date = current_due_date + timedelta(days=30 * months)
            self._execute("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id), commit=True)
            logging.info(f"VPS {vps_id} renewed for {months} months. New due date: {new_due_date}")

    def update_vps_status(self, vps_id, status):
        self._execute("UPDATE vps SET status = ? WHERE id = ?", (status, vps_id), commit=True)
        logging.info(f"VPS {vps_id} status updated to {status}")

    def delete_vps(self, vps_id):
        vps_info = self.get_vps_by_id(vps_id)
        if vps_info:
            self._execute("DELETE FROM vps WHERE id = ?", (vps_id,), commit=True)
            logging.info(f"VPS {vps_id} ({vps_info['container_name']}) deleted from database.")
            return vps_info['container_name']
        return None

    def delete_vps_by_container_name(self, container_name):
        vps_info = self.get_vps_by_container_name(container_name)
        if vps_info:
            self._execute("DELETE FROM vps WHERE container_name = ?", (container_name,), commit=True)
            logging.info(f"VPS ({container_name}) deleted from database.")
            return vps_info['container_name']
        return None

    def update_vps_ssh_link(self, container_name, ssh_link):
        self._execute("UPDATE vps SET ssh_link = ? WHERE container_name = ?", (ssh_link, container_name), commit=True)
        logging.info(f"VPS {container_name} SSH link updated.")

    def update_vps_ssh_credentials(self, container_name, ssh_port, ssh_password):
        self._execute("UPDATE vps SET ssh_port = ?, ssh_password = ? WHERE container_name = ?", (ssh_port, ssh_password, container_name), commit=True)
        logging.info(f"VPS {container_name} SSH credentials updated (port: {ssh_port}).")

    def get_all_ssh_ports(self):
        """Récupère tous les ports SSH utilisés"""
        result = self._execute("SELECT ssh_port FROM vps WHERE ssh_port IS NOT NULL", fetchall=True)
        return [row['ssh_port'] for row in result if row['ssh_port']]

    # Transaction functions
    def add_transaction(self, track_id, user_id, credits, expiration_time):
        self._execute(
            "INSERT INTO transactions (track_id, user_id, credits, expiration_time) VALUES (?, ?, ?, ?)",
            (track_id, user_id, credits, expiration_time),
            commit=True
        )

    def get_unattributed_transactions(self):
        return self._execute("SELECT track_id, user_id, credits, expiration_time, attributed FROM transactions WHERE attributed = 0", fetchall=True)

    def mark_transaction_as_attributed(self, track_id):
        self._execute("UPDATE transactions SET attributed = 1 WHERE track_id = ?", (track_id,), commit=True)

    # Port forwarding functions
    def add_port_forward_entry(self, container_name, external_port, internal_port, protocol, device_name):
        self._execute(
            "INSERT INTO port_forwards (container_name, external_port, internal_port, protocol, device_name) VALUES (?, ?, ?, ?, ?)",
            (container_name, external_port, internal_port, protocol, device_name),
            commit=True
        )
        logging.info(f"Port forward {external_port}:{internal_port}/{protocol} added for {container_name}.")

    def remove_port_forward_entry(self, device_name):
        self._execute("DELETE FROM port_forwards WHERE device_name = ?", (device_name,), commit=True)
        logging.info(f"Port forward device {device_name} removed from database.")

    def get_port_forward_by_external_port(self, external_port, protocol):
        return self._execute("SELECT * FROM port_forwards WHERE external_port = ? AND protocol = ?", (external_port, protocol), fetchone=True)

    def get_port_forwards_for_container(self, container_name):
        return self._execute("SELECT * FROM port_forwards WHERE container_name = ?", (container_name,), fetchall=True)

    def get_transactions_this_month(self):
        now = datetime.now()
        first_day_of_month = datetime(now.year, now.month, 1)
        if now.month == 12:
            first_day_of_next_month = datetime(now.year + 1, 1, 1)
        else:
            first_day_of_next_month = datetime(now.year, now.month + 1, 1)

        start_timestamp = int(first_day_of_month.timestamp())
        end_timestamp = int(first_day_of_next_month.timestamp())

        result = self._execute(
            "SELECT COUNT(*) FROM transactions WHERE expiration_time >= ? AND expiration_time < ?",
            (start_timestamp, end_timestamp),
            fetchone=True
        )
        return result[0] if result else 0

    # Stats functions
    def get_stats_channel_id(self, key):
        result = self._execute("SELECT channel_id FROM channel_stats WHERE channel_key = ?", (key,), fetchone=True)
        return result['channel_id'] if result else None

    def set_stats_channel_id(self, key, channel_id):
        self._execute(
            "INSERT OR REPLACE INTO channel_stats (channel_key, channel_id) VALUES (?, ?)",
            (key, channel_id),
            commit=True
        )

    def delete_stats_channel(self, key):
        self._execute("DELETE FROM channel_stats WHERE channel_key = ?", (key,), commit=True)

    # Monthly trial functions
    def record_monthly_trial_receipt(self, user_id):
        self._execute("INSERT OR IGNORE INTO monthly_trial_users (user_id) VALUES (?)", (user_id,), commit=True)
        logging.info(f"User {user_id} recorded as having received monthly trial credits.")

    def has_received_monthly_trial(self, user_id):
        result = self._execute("SELECT user_id FROM monthly_trial_users WHERE user_id = ?", (user_id,), fetchone=True)
        return result is not None

    def save_monthly_trial_message_id(self, message_id, channel_id):
        self._execute("INSERT OR REPLACE INTO monthly_trial_message (id, message_id, channel_id) VALUES (1, ?, ?)", (message_id, channel_id), commit=True)
        logging.info(f"Monthly trial message ID {message_id} saved for channel {channel_id}.")

    def get_monthly_trial_message_id(self):
        result = self._execute("SELECT message_id, channel_id FROM monthly_trial_message WHERE id = 1", fetchone=True)
        return result if result else (None, None)

    def remove_monthly_trial_receipt(self, user_id):
        self._execute("DELETE FROM monthly_trial_users WHERE user_id = ?", (user_id,), commit=True)
        logging.info(f"User {user_id} removed from monthly trial receipt records.")



    def remove_credits(self, user_id, amount):
        self._execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (amount, user_id), commit=True)
        logging.info(f"User {user_id} had {amount} credits removed.")

    # Invite tracker functions
    def add_invited_member(self, member_id, inviter_id, joined_at):
        self._execute(
            "INSERT INTO invited_members (member_id, inviter_id, joined_at) VALUES (?, ?, ?)",
            (member_id, inviter_id, joined_at),
            commit=True
        )
        logging.info(f"Member {member_id} invited by {inviter_id} recorded.")

    def update_member_leave_time(self, member_id, left_at):
        self._execute(
            "UPDATE invited_members SET left_at = ? WHERE member_id = ?",
            (left_at, member_id),
            commit=True
        )
        logging.info(f"Member {member_id} leave time updated to {left_at}.")

    def get_invited_member(self, member_id):
        return self._execute(
            "SELECT * FROM invited_members WHERE member_id = ?",
            (member_id,),
            fetchone=True
        )

    def get_members_invited_by(self, inviter_id):
        return self._execute(
            "SELECT * FROM invited_members WHERE inviter_id = ?",
            (inviter_id,),
            fetchall=True
        )

    def get_inviter_leaderboard_data(self):
        return self._execute(
            """
            SELECT
                inviter_id,
                SUM(CASE WHEN left_at IS NULL THEN 1 ELSE 0 END) as valid_invites_count,
                SUM(CASE WHEN left_at IS NOT NULL THEN 1 ELSE 0 END) as left_invites_count
            FROM invited_members
            GROUP BY inviter_id
            ORDER BY valid_invites_count DESC
            """,
            fetchall=True
        )

    def mark_invite_reward_given(self, member_id):
        self._execute(
            "UPDATE invited_members SET reward_given = 1 WHERE member_id = ?",
            (member_id,),
            commit=True
        )
        logging.info(f"Reward marked as given for member {member_id}.")

    def get_members_to_check_for_reward(self):
        five_days_ago = datetime.now() - timedelta(days=5)
        return self._execute(
            "SELECT member_id, inviter_id FROM invited_members WHERE joined_at <= ? AND left_at IS NULL AND reward_given = 0",
            (five_days_ago,),
            fetchall=True
        )

    # Giveaway functions
    def get_last_giveaway_transaction_count(self):
        result = self._execute("SELECT last_transaction_count FROM giveaway_stats WHERE id = 1", fetchone=True)
        return result['last_transaction_count'] if result else 0

    def update_last_giveaway_transaction_count(self, count):
        self._execute("INSERT OR REPLACE INTO giveaway_stats (id, last_transaction_count) VALUES (1, ?)", (count,), commit=True)

    # TOS message functions
    def save_tos_message_id(self, message_id, channel_id):
        self._execute("INSERT OR REPLACE INTO tos_message (id, message_id, channel_id) VALUES (1, ?, ?)", (message_id, channel_id), commit=True)
        logging.info(f"TOS message ID {message_id} saved for channel {channel_id}.")

    def get_tos_message_id(self):
        result = self._execute("SELECT message_id, channel_id FROM tos_message WHERE id = 1", fetchone=True)
        return result if result else (None, None)

    def add_suspicion_log(self, container_name, process_list):
        self._execute(
            "INSERT INTO suspicion_logs (container_name, process_list) VALUES (?, ?)",
            (container_name, process_list),
            commit=True
        )

    def get_suspicion_logs(self, container_name, limit=3):
        return self._execute(
            "SELECT process_list FROM suspicion_logs WHERE container_name = ? ORDER BY detected_at DESC LIMIT ?",
            (container_name, limit),
            fetchall=True
        )

    def clear_suspicion_logs(self, container_name):
        self._execute("DELETE FROM suspicion_logs WHERE container_name = ?", (container_name,), commit=True)

    def unsuspend_vps(self, container_name):
        self._execute("UPDATE vps SET is_suspended = 0 WHERE container_name = ?", (container_name,), commit=True)
        logging.info(f"VPS {container_name} has been unsuspended.")

db = Database("database.db")