import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
import asyncio
from utils.renew_vps import RenewModal
from commands.plans import PRICES, usd_to_credits
import math
import re
from datetime import datetime

# ====================================================================================================================
# 1. CONSTANTS & CONFIG
# ====================================================================================================================

MINING_PORTS = [
    3333, 4444, 5555, 7777, 8888, 9999, 14444, 45700, 1800, 8000, 8001, 8008, 8118, 9000, 9001, 12000, 65000,
    25, 80, 443, 302, 303, 44158, 44159, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009,
    6000, 6001, 6002, 6003, 6004, 6005, 6006, 6007, 6008, 6009, 7000, 7001, 7002, 7003, 7004, 7005,
    7006, 7007, 7008, 7009,
]

# ====================================================================================================================
# 2. HELPER FUNCTIONS
# ====================================================================================================================

def _create_embed(title: str, description: str, color: discord.Color = discord.Color.orange()) -> discord.Embed:
    """Creates a Discord embed with a consistent style."""
    return discord.Embed(title=title, description=description, color=color)

# ====================================================================================================================
# 3. UI COMPONENTS (VIEWS & MODALS)
# ====================================================================================================================

class AuthorRestrictedView(discord.ui.View):
    """A view that only allows the original author of the command to interact."""
    def __init__(self, author_id: int, timeout=180):
        super().__init__(timeout=timeout)
        self.author_id = author_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user and interaction.user.id == self.author_id:
            return True
        await interaction.response.send_message(
            embed=_create_embed("Permission Denied", "You are not authorized to interact with this.", discord.Color.red()),
            ephemeral=True
        )
        return False

class PortForwardView(AuthorRestrictedView):
    """View for managing port forwarding on a VPS."""
    def __init__(self, author_id: int, container_name: str, bot: commands.Bot, existing_forwards: list, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.bot = bot
        self.existing_forwards = existing_forwards
        self.manage_cog = manage_cog

    @discord.ui.button(label="Add Port", style=discord.ButtonStyle.success)
    async def add_port(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = PortForwardModal(self.container_name, self.bot, self.existing_forwards)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Delete Port", style=discord.ButtonStyle.danger)
    async def delete_port(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = PortDeleteModal(self.container_name, self.bot)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Refresh", style=discord.ButtonStyle.secondary)
    async def refresh_ports(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        
        result = await api_get(f"/lxc/container/{self.container_name}/ports")
        updated_forwards = result.get("ports", []) if result else []

        if updated_forwards:
            forward_list = [f"- {f} (jupyterhive.duckdns.org:{f.split('/')[0]})" for f in updated_forwards]
            description = "```\n" + "\n".join(forward_list) + "\n```"
            embed = _create_embed(f"Forwarded Ports for {self.container_name}", description)
        else:
            embed = _create_embed(f"Forwarded Ports for {self.container_name}", "No ports are currently forwarded.")
        
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary)
    async def back_to_vps_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog.display_vps_info(interaction, self.container_name)

class ConfirmReinstallView(AuthorRestrictedView):
    """Confirmation view for reinstalling a VPS."""
    def __init__(self, author_id: int, container_name: str, manage_cog, original_embed: discord.Embed):
        super().__init__(author_id, timeout=60)
        self.container_name = container_name
        self.manage_cog = manage_cog
        self.original_embed = original_embed

    @discord.ui.button(label="Confirm Reinstall", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(
            embed=_create_embed("Reinstalling...", "Please wait while your VPS is being reinstalled. This may take some time.", discord.Color.blue()),
            view=self
        )

        reinstall_result = await api_post(f"/lxc/container/{self.container_name}/reinstall")
        
        if reinstall_result and reinstall_result.get("status") == "success":
            result_data = reinstall_result.get("result", [])
            if len(result_data) == 4:
                new_container_name, new_ssh_link, _, new_ssh_password = result_data
                private_ssh_embed = _create_embed(
                    f"New SSH Details for {new_container_name}",
                    f"**SSH Link:**\n```\n{new_ssh_link}\n```\n**Password:**\n```\n{new_ssh_password}\n```"
                )
                await interaction.followup.send(embed=private_ssh_embed, ephemeral=True)

                await interaction.edit_original_response(
                    content=None,
                    embed=_create_embed("Reinstall Success", f"{self.container_name} was reinstalled as {new_container_name}. New SSH credentials have been sent to you.", discord.Color.green()),
                    view=None
                )
            else:
                await interaction.edit_original_response(
                    content=None,
                    embed=_create_embed("Reinstall Failed", f"API returned unexpected data for {self.container_name}.", discord.Color.red()),
                    view=None
                )
        else:
            await interaction.edit_original_response(
                content=None,
                embed=_create_embed("Reinstall Failed", f"Failed to reinstall {self.container_name}.", discord.Color.red()),
                view=None
            )
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=_create_embed("Cancelled", "Reinstallation has been cancelled.", discord.Color.greyple()),
            view=None
        )
        self.stop()

async def api_delete(endpoint: str):
    headers = {'X-API-KEY': API_KEY}
    async with aiohttp.ClientSession() as session:
        async with session.delete(f"{API_BASE_URL}{endpoint}", headers=headers) as response:
            if response.status == 200:
                return await response.json()
            return None

class ConfirmDeleteView(AuthorRestrictedView):
    """Confirmation view for deleting a VPS."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=60)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="Confirm Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=_create_embed("Deleting VPS", f"Stopping and deleting {self.container_name}...", discord.Color.blue()),
            view=None
        )
        
        stop_result = await api_post(f"/lxc/container/{self.container_name}/stop", data={"force": True})
        if not stop_result or stop_result.get("result") is False:
            await interaction.edit_original_response(
                embed=_create_embed("Deletion Aborted", f"Failed to stop {self.container_name}. Deletion aborted.", discord.Color.red())
            )
            return

        delete_result = await api_delete(f"/lxc/container/{self.container_name}")
        if delete_result and delete_result.get("deleted"):
            db.delete_vps_by_container_name(self.container_name)
            await interaction.edit_original_response(
                embed=_create_embed("Deletion Success", f"{self.container_name} has been permanently deleted.", discord.Color.green())
            )
        else:
            await interaction.edit_original_response(
                embed=_create_embed("Deletion Failed", f"Failed to delete {self.container_name}.", discord.Color.red())
            )


    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=_create_embed("Cancelled", "Deletion has been cancelled.", discord.Color.greyple()),
            view=None
        )

class PortDeleteModal(discord.ui.Modal, title="Delete Port Forward"):
    port_input = discord.ui.TextInput(label="Port to Delete", placeholder="e.g., 8080", required=True)

    def __init__(self, container_name: str, bot: commands.Bot):
        super().__init__()
        self.container_name = container_name
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        port_to_delete_str = self.port_input.value.strip()
        if not port_to_delete_str.isdigit():
            await interaction.followup.send(embed=_create_embed("Invalid Input", "Please enter a valid port number.", discord.Color.red()), ephemeral=True)
            return
        
        port_to_delete = int(port_to_delete_str)
        result = await api_delete(f"/lxc/container/{self.container_name}/ports", data={"port": port_to_delete})

        if result and result.get("result"):
            embed = _create_embed("Success", f"Port forward for port {port_to_delete} has been deleted.", discord.Color.green())
        else:
            embed = _create_embed("Error", f"Failed to delete port {port_to_delete}. It might not exist or an error occurred.", discord.Color.red())
        await interaction.followup.send(embed=embed, ephemeral=True)

class PortForwardModal(discord.ui.Modal, title="Add Port Forward"):
    ports_input = discord.ui.TextInput(label="Ports to Forward (hyphen-separated)", placeholder="e.g., 80-443-8080", required=True)

    def __init__(self, container_name: str, bot: commands.Bot, existing_forwards: list):
        super().__init__()
        self.container_name = container_name
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        ports_str = self.ports_input.value
        ports_to_forward = [p.strip() for p in ports_str.split('-') if p.strip().isdigit()]

        if not ports_to_forward:
            await interaction.followup.send(embed=_create_embed("Invalid Input", "Please enter valid port numbers separated by hyphens.", discord.Color.red()), ephemeral=True)
            return

        success_messages, error_messages = [], []
        for port in ports_to_forward:
            if int(port) in MINING_PORTS:
                error_messages.append(f":x: Port {port} is a known mining port and cannot be forwarded.")
                continue
            try:
                result = await api_post(f"/lxc/container/{self.container_name}/ports", data={"port": int(port)})
                if result and result.get("result"):
                    success_messages.append(f":white_check_mark: Port {port} forwarded to jupyterhive.duckdns.org:{port}")
                else:
                    error_messages.append(f":x: Failed to forward port {port}. (API Error)")
            except Exception as e:
                error_messages.append(f":x: Error forwarding port {port}: {e}")
        
        description = ""
        if success_messages:
            description += "**Successes:**\n" + "\n".join(success_messages)
        if error_messages:
            description += "\n\n**Errors:**\n" + "\n".join(error_messages)

        color = discord.Color.green() if not error_messages else (discord.Color.red() if not success_messages else discord.Color.orange())
        await interaction.followup.send(embed=_create_embed("Port Forwarding Results", description, color), ephemeral=True)


class VPSActionView(AuthorRestrictedView):
    """Main view for VPS actions."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, custom_id="start")
    async def start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._start_callback(interaction, self.container_name)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, custom_id="restart")
    async def restart_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._restart_callback(interaction, self.container_name)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.danger, custom_id="stop")
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._stop_callback(interaction, self.container_name)

    @discord.ui.button(label="Reinstall", style=discord.ButtonStyle.secondary, custom_id="reinstall")
    async def reinstall_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._reinstall_callback(interaction, self.container_name)

    @discord.ui.button(label="Other", style=discord.ButtonStyle.primary, custom_id="other")
    async def other_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._other_callback(interaction, self.container_name)


class OtherActionsView(AuthorRestrictedView):
    """View for additional VPS actions."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="View SSH", style=discord.ButtonStyle.primary, custom_id="view_ssh")
    async def view_ssh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._view_ssh_callback(interaction, self.container_name)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, custom_id="delete")
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._delete_callback(interaction, self.container_name)

    @discord.ui.button(label="Port Forward", style=discord.ButtonStyle.secondary, custom_id="port_forward")
    async def port_forward_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._port_forward_callback(interaction, self.container_name)

    @discord.ui.button(label="Renew", style=discord.ButtonStyle.success, custom_id="renew")
    async def renew_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = RenewModal(self.container_name)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, custom_id="back")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog.display_vps_info(interaction, self.container_name)


# ====================================================================================================================
# 4. MANAGE COMMAND COG
# ====================================================================================================================

import aiohttp
import os

API_BASE_URL = os.getenv("API_URL", "http://127.0.0.1:5000")
API_KEY = os.getenv("API_KEY")

# Helper for API calls
async def api_get(endpoint: str):
    headers = {'X-API-KEY': API_KEY}
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{API_BASE_URL}{endpoint}", headers=headers) as response:
            if response.status == 200:
                return await response.json()
            # Log or handle errors appropriately
            return None

class Manage(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="manage", description="View and manage your VPS instances.")
    @app_commands.guild_only()
    async def manage_vps(self, ctx: commands.Context):
        user_id = str(ctx.author.id)
        user_containers = await api_get(f"/lxc/user/{user_id}")

        if not user_containers:
            await ctx.send(embed=_create_embed("No VPS Found", "You don't have any VPS instances yet."))
            return

        if len(user_containers) == 1:
            await self.display_vps_info(ctx, user_containers[0])
        else:
            select_options = [discord.SelectOption(label=name, value=name) for name in user_containers]
            select = discord.ui.Select(placeholder="Choose a VPS to manage...", options=select_options, custom_id="vps_select")

            async def select_callback(interaction: discord.Interaction):
                selected_container = interaction.data["values"][0]
                await self.display_vps_info(interaction, selected_container)

            select.callback = select_callback
            view = AuthorRestrictedView(ctx.author.id, timeout=180)
            view.add_item(select)
            await ctx.send(embed=_create_embed("Your VPS Instances", "You have multiple VPS. Select one to manage."), view=view)

    async def display_vps_info(self, ctx, container_name: str):
        vps_info_raw = await api_get(f"/lxc/container/{container_name}/info")
        vps_db_info_row = db.get_vps_by_container_name(container_name)
        
        # Debug log
        import logging
        logging.info(f"DEBUG - vps_info_raw for {container_name}: {vps_info_raw}")
        logging.info(f"DEBUG - vps_info_raw type: {type(vps_info_raw)}")
        
        # Convert sqlite3.Row to dict to use .get() method
        vps_db_info = dict(vps_db_info_row) if vps_db_info_row else None
        
        status, ipv4, ram_usage, disk_usage, uptime = "N/A", "N/A", "N/A", "N/A", "N/A"
        cpu_lxc, ram_lxc, disk_lxc = "N/A", "N/A", "N/A"
        is_running = False

        lxc_config_raw = await api_get(f"/lxc/container/{container_name}/config")
        if lxc_config_raw:
            cpu_lxc = lxc_config_raw.get('config', {}).get('limits.cpu', 'N/A')
            ram_lxc_raw = lxc_config_raw.get('config', {}).get('limits.memory', 'N/A')
            disk_lxc_raw = lxc_config_raw.get('devices', {}).get('root', {}).get('size', 'N/A')
            
            # Convert RAM to GB
            if ram_lxc_raw != 'N/A':
                if 'MB' in ram_lxc_raw:
                    ram_mb = float(ram_lxc_raw.replace('MB', ''))
                    ram_lxc = f"{ram_mb / 1024:.2f}GB"
                elif 'GB' in ram_lxc_raw:
                    ram_lxc = ram_lxc_raw
                else:
                    ram_lxc = ram_lxc_raw
            else:
                ram_lxc = 'N/A'
            
            # Convert Disk to GB
            if disk_lxc_raw != 'N/A':
                if 'MB' in disk_lxc_raw:
                    disk_mb = float(disk_lxc_raw.replace('MB', ''))
                    disk_lxc = f"{disk_mb / 1024:.2f}GB"
                elif 'GB' in disk_lxc_raw:
                    disk_lxc = disk_lxc_raw
                else:
                    disk_lxc = disk_lxc_raw
            else:
                disk_lxc = 'N/A'

        # Check if container info was retrieved successfully
        if vps_info_raw and isinstance(vps_info_raw, dict):
            status = vps_info_raw.get('status', 'N/A')
            logging.info(f"DEBUG - status from vps_info_raw: {status}")
            # Handle both 'Running' and 'Stopped' status from lxc
            is_running = status.lower() == 'running'
            logging.info(f"DEBUG - is_running: {is_running}")
            
            # Get IPv4 only if container is running
            if is_running:
                # Try to get IP directly from lxc list command (more reliable)
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "lxc", "list", container_name, "--format", "csv", "-c", "4",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, _ = await proc.communicate()
                    if proc.returncode == 0:
                        ip_output = stdout.decode().strip()
                        # Format is like "10.137.11.200 (eth0)"
                        match = re.search(r'([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)', ip_output)
                        if match:
                            ipv4 = match.group(1)
                            logging.info(f"DEBUG - Found IP from lxc list: {ipv4}")
                except Exception as e:
                    logging.warning(f"Could not get IP from lxc list: {e}")
                
                # Fallback: Parse from lxc info YAML
                if ipv4 == 'N/A':
                    network_info = vps_info_raw.get('Network usage', {})
                    logging.info(f"DEBUG - Network info: {network_info}")
                    
                    for interface_name, interface_data in network_info.items():
                        if interface_name == 'lo':  # Skip loopback
                            continue
                        
                        logging.info(f"DEBUG - Checking interface {interface_name}: {interface_data}")
                        
                        ip_addresses = interface_data.get('IP addresses', [])
                        logging.info(f"DEBUG - IP addresses found: {ip_addresses}")
                        
                        for addr_info in ip_addresses:
                            logging.info(f"DEBUG - Processing addr_info: {addr_info} (type: {type(addr_info)})")
                            
                            # Format is like "inet:  10.137.11.200/24 (global)"
                            if isinstance(addr_info, dict):
                                if addr_info.get('family') == 'inet' and addr_info.get('scope') == 'global':
                                    ipv4 = addr_info.get('address', 'N/A')
                                    logging.info(f"DEBUG - Found IP (dict format): {ipv4}")
                                    break
                            elif isinstance(addr_info, str):
                                # Parse string format "inet:  10.137.11.200/24 (global)"
                                if 'inet:' in addr_info and 'global' in addr_info:
                                    match = re.search(r'inet:\s+([0-9.]+)', addr_info)
                                    if match:
                                        ipv4 = match.group(1)
                                        logging.info(f"DEBUG - Found IP (string format): {ipv4}")
                                        break
                                # Also try format without "inet:" prefix
                                elif 'global' in addr_info or '/' in addr_info:
                                    match = re.search(r'([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)', addr_info)
                                    if match:
                                        ip_candidate = match.group(1)
                                        if not ip_candidate.startswith('127.'):
                                            ipv4 = ip_candidate
                                            logging.info(f"DEBUG - Found IP (alternate format): {ipv4}")
                                            break
                        
                        if ipv4 != 'N/A':
                            break

                # Get resource usage - LXC uses different keys
                resources = vps_info_raw.get('Resources', {})
                
                # Memory usage - format: "Memory (current): 166.36MiB"
                memory_str = resources.get('Memory usage', {}).get('Memory (current)', '0')
                if isinstance(memory_str, str):
                    if 'MiB' in memory_str or 'MB' in memory_str:
                        ram_usage_mb = float(re.search(r'([\d.]+)', memory_str).group(1)) if re.search(r'([\d.]+)', memory_str) else 0
                        ram_usage_bytes = ram_usage_mb * (1024 * 1024)
                    elif 'GiB' in memory_str or 'GB' in memory_str:
                        ram_usage_gb = float(re.search(r'([\d.]+)', memory_str).group(1)) if re.search(r'([\d.]+)', memory_str) else 0
                        ram_usage_bytes = ram_usage_gb * (1024 * 1024 * 1024)
                    else:
                        ram_usage_bytes = 0
                else:
                    ram_usage_bytes = 0
                
                # Disk usage - format: "root: 511.42MiB"
                disk_info = resources.get('Disk usage', {})
                disk_str = disk_info.get('root', '0') if isinstance(disk_info, dict) else '0'
                if isinstance(disk_str, str):
                    if 'MiB' in disk_str or 'MB' in disk_str:
                        disk_usage_mb = float(re.search(r'([\d.]+)', disk_str).group(1)) if re.search(r'([\d.]+)', disk_str) else 0
                        disk_usage_bytes = disk_usage_mb * (1024 * 1024)
                    elif 'GiB' in disk_str or 'GB' in disk_str:
                        disk_usage_gb = float(re.search(r'([\d.]+)', disk_str).group(1)) if re.search(r'([\d.]+)', disk_str) else 0
                        disk_usage_bytes = disk_usage_gb * (1024 * 1024 * 1024)
                    else:
                        disk_usage_bytes = 0
                else:
                    disk_usage_bytes = 0

                # Calculate uptime from timestamps
                created_str = vps_info_raw.get('Created', '')
                last_used_str = vps_info_raw.get('Last Used', '')
                uptime_seconds = 0
                
                if created_str and last_used_str:
                    try:
                        from datetime import datetime
                        # Parse format: "2025/10/23 20:19 CEST"
                        created = datetime.strptime(created_str.rsplit(' ', 1)[0], "%Y/%m/%d %H:%M")
                        now = datetime.now()
                        uptime_seconds = int((now - created).total_seconds())
                    except:
                        uptime_seconds = 0

                ram_usage = f"{ram_usage_bytes / (1024**2):.2f} MB" if ram_usage_bytes > 0 else "0 MB"
                disk_usage = f"{disk_usage_bytes / (1024**3):.2f} GB" if disk_usage_bytes > 0 else "0 GB"
                
                if uptime_seconds > 0:
                    days = uptime_seconds // (24 * 3600)
                    uptime_seconds %= (24 * 3600)
                    hours = uptime_seconds // 3600
                    uptime_seconds %= 3600
                    minutes = uptime_seconds // 60
                    uptime = f"{days}d {hours}h {minutes}m"
                else:
                    uptime = "Just started"
            else:
                ipv4 = "Container stopped"
                ram_usage = "Container stopped"
                disk_usage = "Container stopped"
                uptime = "Container stopped"
        else:
            # If vps_info_raw is None or not a dict, set default values
            status = "Unknown"
            ipv4 = "Unable to retrieve"
            ram_usage = "Unable to retrieve"
            disk_usage = "Unable to retrieve"
            uptime = "Unable to retrieve"
        
        # Build description without emojis
        status_display = status.capitalize() if status != "N/A" else "Unknown"
        
        description = f"**Status:** {status_display}\n" + \
                      f"**IPv4 Public:** `31.58.58.81`\n" + \
                      f"**IPv4 Private:** ||`{ipv4}`||\n" + \
                      f"**Uptime:** {uptime}\n"

        embed = _create_embed(f"VPS Management: {container_name}", description)
        
        embed.add_field(name="Resources", value=f"**CPU:** {cpu_lxc} core(s)\n**RAM:** {ram_lxc}\n**Disk:** {disk_lxc}", inline=False)
        
        if is_running:
            embed.add_field(name="Usage", value=f"**RAM:** {ram_usage}\n**Disk:** {disk_usage}", inline=False)
        else:
            embed.add_field(name="Usage", value="*Container must be running to display usage*", inline=False)

        if vps_db_info:
            try:
                due_date_raw = vps_db_info.get('due_date')
                cost = vps_db_info.get('cost')
                
                # Format due date nicely
                if due_date_raw:
                    try:
                        # Parse the date if it's a string
                        if isinstance(due_date_raw, str):
                            due_date_obj = datetime.fromisoformat(due_date_raw)
                            due_date_formatted = due_date_obj.strftime("%Y-%m-%d %H:%M")
                        else:
                            due_date_formatted = str(due_date_raw)
                        embed.add_field(name="Due Date", value=f"{due_date_formatted}", inline=True)
                    except:
                        embed.add_field(name="Due Date", value=f"{due_date_raw}", inline=True)
                
                if cost:
                    embed.add_field(name="Monthly Cost", value=f"{cost} credits", inline=True)
            except (KeyError, TypeError):
                pass

        user_id = ctx.author.id if isinstance(ctx, commands.Context) else ctx.user.id
        view = VPSActionView(user_id, container_name, self)

        if hasattr(ctx, 'response') and not ctx.response.is_done():
            await ctx.response.send_message(embed=embed, view=view, ephemeral=True)
        elif hasattr(ctx, 'edit_original_response'):
            await ctx.edit_original_response(embed=embed, view=view)
        else:
            await ctx.send(embed=embed, view=view)

async def api_post(endpoint: str, data: dict = None):
    headers = {'X-API-KEY': API_KEY}
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{API_BASE_URL}{endpoint}", headers=headers, json=data) as response:
            if response.status == 200:
                return await response.json()
            return None

class Manage(commands.Cog):
    # ... (previous code remains the same)
    # ...

    # ----------------------------------------------------------------------------------------------------------------
    # 5. ACTION CALLBACKS
    # ----------------------------------------------------------------------------------------------------------------

    async def _restart_callback(self, interaction: discord.Interaction, container_name: str):
        if db.is_vps_suspended(container_name):
            await interaction.response.send_message(embed=_create_embed("Action Failed", "This VPS is suspended and cannot be restarted.", discord.Color.red()), ephemeral=True)
            return

        await interaction.response.defer(ephemeral=False)
        await interaction.followup.send(embed=_create_embed("Restarting...", f"The restart command has been sent for {container_name}. This may take a moment.", discord.Color.blue()), ephemeral=True)

        result = await api_post(f"/lxc/container/{container_name}/restart")

        if result and result.get("status") == "success":
            await asyncio.sleep(5) # Give time for the container to boot
            ssh_result = await api_post(f"/lxc/container/{container_name}/regenerate-ssh")
            if ssh_result and ssh_result.get("status") == "success":
                new_ssh = ssh_result.get("ssh_link")
                db.update_vps_ssh_link(container_name, new_ssh)
            
            await self.display_vps_info(interaction, container_name)
            await interaction.followup.send(embed=_create_embed("Success", f"{container_name} restarted successfully.", discord.Color.green()), ephemeral=True)
        else:
            await interaction.followup.send(embed=_create_embed("Restart Failed", f"An error occurred while restarting {container_name}.", discord.Color.red()), ephemeral=True)

    async def _stop_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        await interaction.followup.send(embed=_create_embed("Processing", f"Stopping {container_name}...", discord.Color.blue()), ephemeral=True)
        
        result = await api_post(f"/lxc/container/{container_name}/stop", data={"force": True})

        if result and result.get("status") == "success":
            api_result = result.get("result")
            if api_result is True:
                db.update_vps_ssh_link(container_name, None)
                embed = _create_embed("Success", f"{container_name} stopped successfully.", discord.Color.green())
            elif api_result is None:
                db.update_vps_ssh_link(container_name, None)
                embed = _create_embed("Info", f"{container_name} is already stopped.", discord.Color.blue())
            else:
                embed = _create_embed("Error", f"Failed to stop {container_name}.", discord.Color.red())
        else:
            embed = _create_embed("Error", f"API Error: Failed to stop {container_name}.", discord.Color.red())
        
        await interaction.edit_original_response(content=None, embed=embed, view=None)

    async def _start_callback(self, interaction: discord.Interaction, container_name: str):
        if db.is_vps_suspended(container_name):
            await interaction.response.send_message(embed=_create_embed("Action Failed", "This VPS is suspended.", discord.Color.red()), ephemeral=True)
            return

        await interaction.response.defer()
        await interaction.followup.send(embed=_create_embed("Processing", f"Starting {container_name}...", discord.Color.blue()), ephemeral=True)

        result = await api_post(f"/lxc/container/{container_name}/start")

        if result and result.get("status") == "success":
            api_result = result.get("result")
            if api_result is True:
                await asyncio.sleep(5)
                ssh_result = await api_post(f"/lxc/container/{container_name}/regenerate-ssh")
                if ssh_result and ssh_result.get("status") == "success":
                    new_ssh = ssh_result.get("ssh_link")
                    db.update_vps_ssh_link(container_name, new_ssh)
                await self.display_vps_info(interaction, container_name)
            elif api_result is None:
                await interaction.followup.send(embed=_create_embed("Info", f"{container_name} is already running.", discord.Color.blue()), ephemeral=True)
            else:
                await interaction.followup.send(embed=_create_embed("Error", f"Failed to start {container_name}.", discord.Color.red()), ephemeral=True)
        else:
            await interaction.followup.send(embed=_create_embed("Error", f"API Error: Failed to start {container_name}.", discord.Color.red()), ephemeral=True)

    async def _reinstall_callback(self, interaction: discord.Interaction, container_name: str):
        if db.is_vps_suspended(container_name):
            await interaction.response.send_message(embed=_create_embed("Action Failed", "This VPS is suspended.", discord.Color.red()), ephemeral=True)
            return

        view = ConfirmReinstallView(interaction.user.id, container_name, self, None)
        embed = _create_embed("Confirmation Required", f"This will delete and recreate **{container_name}**. Are you sure?", discord.Color.red())
        await interaction.response.send_message(embed=embed, ephemeral=True, view=view)

    async def _view_ssh_callback(self, interaction: discord.Interaction, container_name: str):
        vps_db_info_row = db.get_vps_by_container_name(container_name)
        
        # Convert sqlite3.Row to dict to use .get() method
        vps_db_info = dict(vps_db_info_row) if vps_db_info_row else None
        
        if vps_db_info:
            ssh_link = vps_db_info.get('ssh_link') or "N/A"
            ssh_password = vps_db_info.get('ssh_password') or "N/A"
        else:
            ssh_link = "N/A"
            ssh_password = "N/A"
        
        port = "N/A"
        if ssh_link != "N/A":
            port_match = re.search(r"-p (\d+)", ssh_link)
            if port_match:
                port = port_match.group(1)

        desc = f"**SSH Link:**\n```\n{ssh_link}\n```\n**Password:**\n```\n{ssh_password}\n```\n**Port:** {port}"
        embed = _create_embed(f"SSH Details for {container_name}", desc)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def _delete_callback(self, interaction: discord.Interaction, container_name: str):
        view = ConfirmDeleteView(interaction.user.id, container_name, self)
        embed = _create_embed("Confirmation Required", f"Are you sure you want to delete **{container_name}**? This action cannot be undone.", discord.Color.red())
        await interaction.response.send_message(embed=embed, ephemeral=True, view=view)

    async def _port_forward_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        
        result = await api_get(f"/lxc/container/{container_name}/ports")
        existing_forwards = result.get("ports", []) if result else []

        if existing_forwards:
            forward_list = [f"- {f} (jupyterhive.duckdns.org:{f.split('/')[0]})" for f in existing_forwards]
            description = "```\n" + "\n".join(forward_list) + "\n```"
            embed = _create_embed(f"Forwarded Ports for {container_name}", description)
        else:
            embed = _create_embed(f"Forwarded Ports for {container_name}", "No ports are currently forwarded.")
        
        view = PortForwardView(interaction.user.id, container_name, self.bot, existing_forwards, self)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    async def _other_callback(self, interaction: discord.Interaction, container_name: str):
        view = OtherActionsView(interaction.user.id, container_name, self)
        await interaction.response.edit_message(view=view)


async def setup(bot):
    await bot.add_cog(Manage(bot))