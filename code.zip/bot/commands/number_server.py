
import discord
from discord.ext import tasks, commands
from utils.database import db
from datetime import datetime
import os
import aiohttp
import json
import asyncio

class ServerStats(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.category_id = 1338194380602736721
        self.update_stats.start()

    def cog_unload(self):
        self.update_stats.cancel()

    @tasks.loop(minutes=5)
    async def update_stats(self):
        await self.bot.wait_until_ready()
        category = self.bot.get_channel(self.category_id)
        if not category:
            return

        guild = category.guild

        # Get stats
        humans = sum(1 for member in guild.members if not member.bot)
        bots = sum(1 for member in guild.members if member.bot)
        
        # Get active VPS count from lxc list
        try:
            proc = await asyncio.create_subprocess_shell(
                'lxc list --format=json',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode == 0:
                lxc_list = json.loads(stdout)
                active_vps = sum(1 for c in lxc_list if c['status'] == 'Running')
            else:
                active_vps = 'N/A'
        except (json.JSONDecodeError, KeyError, FileNotFoundError):
            active_vps = 'N/A'

        # Get transactions count from OxaPay API
        transactions_this_month = 'N/A'
        merchant_api_key = os.getenv("OXAPAY_MERCHANT_KEY")
        if merchant_api_key:
            now = datetime.now()
            first_day_of_month = datetime(now.year, now.month, 1)
            if now.month == 12:
                first_day_of_next_month = datetime(now.year + 1, 1, 1)
            else:
                first_day_of_next_month = datetime(now.year, now.month + 1, 1)

            start_timestamp = int(first_day_of_month.timestamp())
            end_timestamp = int(first_day_of_next_month.timestamp())

            headers = {
                'merchant_api_key': merchant_api_key,
                'Content-Type': 'application/json'
            }
            params = {
                'from_date': start_timestamp,
                'to_date': end_timestamp
            }
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get('https://api.oxapay.com/v1/payment', headers=headers, params=params) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            transactions_this_month = data.get('data', {}).get('meta', {}).get('total', 'N/A')
                except Exception as e:
                    pass # Keep it as N/A if something goes wrong

        # Channel names and prefixes
        channel_info = {
            "humans": {"name": f"Humans: {humans}", "prefix": "Humans:"},
            "bots": {"name": f"Bots: {bots}", "prefix": "Bots:"},
            "vps": {"name": f"Active VPS: {active_vps}", "prefix": "Active VPS:"},
            "transactions": {"name": f"Transactions (month): {transactions_this_month}", "prefix": "Transactions (month):"},
        }

        for key, info in channel_info.items():
            name = info["name"]
            prefix = info["prefix"]
            channel_id = db.get_stats_channel_id(key)
            channel = self.bot.get_channel(channel_id) if channel_id else None

            if channel is None and channel_id is not None:
                # Channel was deleted, so remove it from DB
                db.delete_stats_channel(key)

            if not channel:
                # Search for channel by prefix
                found = False
                for ch in category.voice_channels:
                    if ch.name.startswith(prefix):
                        db.set_stats_channel_id(key, ch.id)
                        channel = ch
                        found = True
                        break
                if not found:
                    try:
                        overwrites = {
                            guild.default_role: discord.PermissionOverwrite(connect=False)
                        }
                        new_channel = await guild.create_voice_channel(name, category=category, overwrites=overwrites)
                        db.set_stats_channel_id(key, new_channel.id)
                    except discord.Forbidden:
                        return
                    except discord.HTTPException as e:
                        return
            
            if channel and channel.name != name:
                try:
                    await channel.edit(name=name)
                except discord.Forbidden:
                    pass
                except discord.HTTPException as e:
                    pass


async def setup(bot):
    await bot.add_cog(ServerStats(bot))
